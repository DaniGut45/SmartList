# Este es un scraping de prueba en una pagina HTML
# Es importante para el proyecto no asi para la aplicación final
import requests
from bs4 import BeautifulSoup
import json
import time

# URL base del sitio a scrapear, con marcador para paginación
base_url = "https://books.toscrape.com/catalogue/page-{}.html"

# Lista para almacenar los productos encontrados
productos = []

# Iteración sobre las primeras 3 páginas del catálogo
for page in range(1, 4):
    url = base_url.format(page)
    print(f"Accediendo a {url}")
    r = requests.get(url)
    soup = BeautifulSoup(r.content, "html.parser")

    # Extrae todos los artículos con clase 'product_pod' (representan libros)
    libros = soup.find_all("article", class_="product_pod")

    # Procesamiento de cada libro encontrado
    for libro in libros:
        # Obtiene el título del libro desde el atributo 'title' de la etiqueta <a>
        titulo = libro.h3.a["title"]

        # Extrae el precio, elimina el símbolo de libra esterlina y lo convierte a float
        precio = libro.find("p", class_="price_color").text.strip().replace("£", "")

        # Obtiene el rating textual desde la clase del primer párrafo (p.ej. 'Three', 'Five')
        rating = libro.p["class"][1]

        # Extrae el estado de disponibilidad (stock)
        stock = libro.find("p", class_="instock availability").text.strip()

        # Agrega el libro a la lista con la información estructurada
        productos.append({
            "titulo": titulo,
            "precio": float(precio),
            "rating": rating,
            "stock": stock
        })

    # Espera un segundo antes de hacer la siguiente petición para evitar sobrecarga
    time.sleep(1)

# Guarda los resultados en un archivo JSON
with open("books_scraped.json", "w", encoding="utf-8") as f:
    json.dump(productos, f, ensure_ascii=False, indent=2)

print(f"\nGuardados {len(productos)} libros en '02_books_scraped.json'")
