import json
import unidecode

# Cargar productos
with open('02.2_productos_dia.json', 'r', encoding='utf-8') as f:
    productos = json.load(f)

# Asignar marca basándose en si el nombre contiene 'dia' (sin importar tildes o mayúsculas)
for producto in productos:
    nombre_normalizado = unidecode.unidecode(producto["nombre"].lower())
    if "dia" in nombre_normalizado:
        producto["marca"] = "Marca Blanca"
    else:
        producto["marca"] = "Desconocida"

# Guardar el archivo actualizado
with open('02.2_productos_dia.json', 'w', encoding='utf-8') as f:
    json.dump(productos, f, indent=2, ensure_ascii=False)

print("Archivo actualizado guardado como 02.2_productos_dia.json")
