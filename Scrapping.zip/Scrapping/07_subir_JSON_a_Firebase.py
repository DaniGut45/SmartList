import firebase_admin
from firebase_admin import credentials, firestore
import json

# Inicializar Firebase
cred = credentials.Certificate("./credenciales_firebase.json")  # <-- CAMBIA esta ruta a tus credenciales de firebase
firebase_admin.initialize_app(cred)
db = firestore.client()

# Leer el archivo JSON con los productos
with open("06_productos_firebase.json", "r", encoding="utf-8") as f:
    productos = json.load(f)

# Subir productos a la colección "productos"
for prod in productos:
    doc_id = str(prod["id"])
    doc_data = {
        "nombre": prod["nombre"],
        "marca": prod["marca"],
        "supermercado": prod["supermercado"]
    }
    
    # Agregar keywords si existen
    if "keywords" in prod:
        doc_data["keywords"] = prod["keywords"]

    # Subir documento
    db.collection("productos").document(doc_id).set(doc_data)

print(f"✅ {len(productos)} productos subidos a Firebase en la colección 'productos'.")