import os
import json
import time
import random
from datetime import datetime
from bs4 import BeautifulSoup
from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# --- Funciones auxiliares ---
#Función para hacer click en el botón de cookies
def hacer_click(driver, por, valor, tiempo_espera=10):
    try:
        WebDriverWait(driver, tiempo_espera).until(EC.element_to_be_clickable((por, valor))).click()
    except Exception as e:
        print(f"[!] No se pudo hacer clic en: {valor} — {e}")

def esperar_elementos(driver, por, valor, multiple=False, tiempo_espera=10):
    try:
        if multiple:
            return WebDriverWait(driver, tiempo_espera).until(
                EC.presence_of_all_elements_located((por, valor))
            )
        else:
            return WebDriverWait(driver, tiempo_espera).until(
                EC.presence_of_element_located((por, valor))
            )
    except Exception as e:
        print(f"[!] Elemento no encontrado: {valor} — {e}")
        return [] if multiple else None
    
#Función para hacer scroll de manera automatica y que se carguen todos los productos de dinámicamente
def hacer_scroll_lento(driver, pausas=10, desplazamiento=300):
    altura_total = driver.execute_script("return document.body.scrollHeight")

    for i in range(pausas):
        driver.execute_script(f"window.scrollBy(0, {desplazamiento});")
        time.sleep(random.uniform(1, 2))  # Pausa para que carguen productos
        nuevo_scroll = driver.execute_script("return window.pageYOffset + window.innerHeight")
        if nuevo_scroll >= altura_total:
            break  # Hemos llegado al final
        altura_total = driver.execute_script("return document.body.scrollHeight")  # Actualiza por si cargó más

#Función para guardar todos los productos en un JSON
def guardar_en_json(productos_nuevos, archivo="02.2_productos_dia.json"):
    # Cargar datos anteriores si el archivo existe
    if os.path.exists(archivo):
        with open(archivo, "r", encoding="utf-8") as f:
            try:
                productos_existentes = json.load(f)
            except json.JSONDecodeError:
                productos_existentes = []
    else:
        productos_existentes = []

    # Unir datos nuevos y existentes
    todos_los_productos = productos_existentes + productos_nuevos

    # Guardar en archivo
    with open(archivo, "w", encoding="utf-8") as f:
        json.dump(todos_los_productos, f, ensure_ascii=False, indent=2)
    print(f"[✔] Añadidos {len(productos_nuevos)} productos. Total: {len(todos_los_productos)} en {archivo}")

def extraer_productos(driver):
    productos_extraidos = []

    try:
        contenedor = esperar_elementos(driver, By.CSS_SELECTOR, '.product-container', multiple=False)
        if not contenedor:
            return []
        html_contenido = contenedor.get_attribute("innerHTML")
        sopa = BeautifulSoup(html_contenido, 'html.parser')
        tarjetas = sopa.find_all('div', attrs={'data-test-id': 'product-card'})

        for tarjeta in tarjetas:
            enlace_tag = tarjeta.find('a')
            if not enlace_tag:
                continue
            enlace = enlace_tag.get('href')
            img = enlace_tag.find('img')
            imagen = img.get('src') if img else ""

            nombre_tag = tarjeta.find('p', class_='search-product-card__product-name')
            nombre = nombre_tag.text.strip() if nombre_tag else ""

            precio_tag = tarjeta.find('p', attrs={'data-test-id': 'search-product-card-unit-price'})
            precio = precio_tag.text.strip().replace(".", "").replace(",", ".").replace("€", "") if precio_tag else ""

            precio_kilo_tag = tarjeta.find('p', attrs={'data-test-id': 'search-product-card-kilo-price'})
            precio_kilo = precio_kilo_tag.text.strip().replace(".", "").replace(",", ".").replace("€", "").replace("/KILO", "").replace("(", "").replace(")", "") if precio_kilo_tag else ""

            productos_extraidos.append({
                #"fecha": str(datetime.now().date()),
                "nombre": nombre,
                "precio": precio,
                #"precio_kilo": precio_kilo,
                #"imagen": imagen,
                #"enlace": "https://www.dia.es" + enlace if enlace else ""
            })

    except Exception as e:
        print(f"[!] Error al extraer productos: {e}")

    return productos_extraidos

# --- Main ---
navegador = Driver(
    browser="chrome",
    uc=True,
    headless2=False,
    incognito=False,
    agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    do_not_track=True,
    undetectable=True
)
navegador.maximize_window()
fecha_actual = datetime.now().date()
print(f"[🕒] Iniciando escaneo: {datetime.now()}")

subcategorias_dia = {
    "airfryer": "https://www.dia.es/freidora-de-aire-airfryer/c/L125",
    "charcuteria-quesos": "https://www.dia.es/charcuteria-y-quesos/c/L101",
    "carniceria": "https://www.dia.es/carniceria/c/L102",
    "pescados-mariscos": "https://www.dia.es/pescados-mariscos-y-ahumados/c/L103",
    "verduras": "https://www.dia.es/verduras/c/L104",
    "frutas": "https://www.dia.es/frutas/c/L105",
    "leche": "https://www.dia.es/leche-huevos-y-mantequilla/c/L108",
    "yogures": "https://www.dia.es/yogures-y-postres/c/L113",
    "pastas": "https://www.dia.es/arroz-pastas-y-legumbres/c/L106",
    "salsas": "https://www.dia.es/aceites-salsas-y-especias/c/L107",
    "conservas": "https://www.dia.es/conservas-caldos-y-cremas/c/L114",
    "panes": "https://www.dia.es/panes-harinas-y-masas/c/L112",
    "cafe": "https://www.dia.es/cafe-cacao-e-infusiones/c/L109",
    "edulcorantes": "https://www.dia.es/azucar-chocolates-y-caramelos/c/L110",
    "galletas": "https://www.dia.es/galletas-bollos-y-cereales/c/L111",
    "aperitivos": "https://www.dia.es/patatas-fritas-encurtidos-y-frutos-secos/c/L115",
    "pizzas": "https://www.dia.es/pizzas-y-platos-preparados/c/L116",
    "congelados": "https://www.dia.es/congelados/c/L119",
    "agua": "https://www.dia.es/agua-refrescos-y-zumos/c/L117",
    "alcohol": "https://www.dia.es/cervezas-vinos-y-bebidas-con-alcohol/c/L118",
    "limpieza": "https://www.dia.es/limpieza-y-hogar/c/L122",
    "perfumeria": "https://www.dia.es/perfumeria-higiene-salud/c/L121",
    "bebe": "https://www.dia.es/bebe/c/L120",
    "mascotas": "https://www.dia.es/mascotas/c/L123",
}

# Ir a la página inicial
url_inicio = "https://www.dia.es/mascotas/c/L123"
navegador.get(url_inicio)
time.sleep(random.uniform(3, 5))

# Aceptar cookies
hacer_click(navegador, By.ID, 'onetrust-accept-btn-handler')

# Obtener lista de subcategorías desde la página inicial
lista_subcategorias = []
categorias_html = esperar_elementos(navegador, By.CSS_SELECTOR, '[data-test-id="categories-list-element"]', multiple=True)

for categoria in categorias_html:
    time.sleep(1)
    html = categoria.get_attribute("innerHTML")
    sopa = BeautifulSoup(html, 'html.parser')
    enlaces = sopa.find_all('a', attrs={'data-test-id': 'sub-category-item-link'})
    urls = [enlace.get('href') for enlace in enlaces]
    for url in urls:
        lista_subcategorias.append("https://www.dia.es" + url)

# Recorrer enlaces y extraer productos
productos_total = []
for url in lista_subcategorias:
    print(f"[➡] Visitando: {url}")
    navegador.get(url)
    delay = random.uniform(6, 10)
    print(f"[⏳] Esperando {delay:.2f} segundos para cargar la página")
    time.sleep(delay)
    hacer_scroll_lento(navegador)  # Hacer scroll para cargar más productos
    productos_encontrados = extraer_productos(navegador)
    print(f"[📦] {len(productos_encontrados)} productos encontrados")
    productos_total.extend(productos_encontrados)

# Guardar resultados
guardar_en_json(productos_total)
navegador.quit()
