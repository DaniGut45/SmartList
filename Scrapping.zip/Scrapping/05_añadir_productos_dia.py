import json
import unicodedata
import re

# -----------------------------
# Funciones auxiliares
# -----------------------------

def normalizar_texto(texto):
    texto = texto.lower()
    texto = unicodedata.normalize('NFD', texto).encode('ascii', 'ignore').decode("utf-8")
    texto = re.sub(r'[^a-z0-9 ]', '', texto)
    return texto.strip()

# -----------------------------
# Cargar archivos
# -----------------------------

with open('04_precios_finales.json', 'r', encoding='utf-8') as f:
    precios_finales = json.load(f)

with open('03_productos_comparados_final.json', 'r', encoding='utf-8') as f:
    productos_comparados = json.load(f)

with open('02.2_productos_dia.json', 'r', encoding='utf-8') as f:
    productos_dia = json.load(f)

# -----------------------------
# Preparar conjunto de nombres ya usados (normalizados)
# -----------------------------

nombres_dia_usados = set()
for match in productos_comparados:
    nombre_dia = match['nombre_dia']
    nombres_dia_usados.add(normalizar_texto(nombre_dia))

# -----------------------------
# Buscar el ID máximo actual
# -----------------------------

# Buscar el ID máximo actual
max_id = max(int(float(prod['id'])) for prod in precios_finales)

# -----------------------------
# Añadir productos DIA no usados
# -----------------------------

for prod_dia in productos_dia:
    nombre_dia = prod_dia['nombre']
    marca_dia = prod_dia['marca']
    precio_dia_str = prod_dia['precio'].replace('\xa0', '').replace(',', '.').strip()

    try:
        precio_dia = float(precio_dia_str)
    except:
        continue  # Si no hay precio, saltar

    nombre_norm = normalizar_texto(nombre_dia)

    if nombre_norm not in nombres_dia_usados:
        max_id += 1
        nuevo_producto = {
            "id": str(max_id),
            "nombre": nombre_dia,
            "marca": marca_dia,
            "supermercado": {
                "mercadona": {
                    "precio": -1
                },
                "dia": {
                    "precio": round(precio_dia, 2)
                }
            }
        }
        precios_finales.append(nuevo_producto)

# -----------------------------
# Guardar el nuevo JSON completo
# -----------------------------

with open('05_precios_finales.json', 'w', encoding='utf-8') as f:
    json.dump(precios_finales, f, indent=2, ensure_ascii=False)

print(f"✅ JSON actualizado. Total productos ahora: {len(precios_finales)}")
