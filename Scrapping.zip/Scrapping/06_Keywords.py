import json
import unidecode
import re

# Función para generar palabras clave útiles, sin números ni términos genéricos o de peso
PALABRAS_EXCLUIDAS = {"de", "con", "en", "el", "la", "los", "las", "y", "x", "o", "a", "para", "un", "una", "pieza", "gramos", "kg", "g", "ml", "l", "unidad", "unidades", "pack", "bote", "botella", "aprox", "igp"}

def generar_keywords(nombre):
    nombre = unidecode.unidecode(nombre.lower())
    nombre = re.sub(r"[^a-z ]", "", nombre)  # Eliminar números y símbolos
    palabras = nombre.split()
    keywords_filtradas = [palabra for palabra in palabras if palabra not in PALABRAS_EXCLUIDAS]
    return list(set(keywords_filtradas))

# Cargar el archivo JSON
with open("05_precios_finales.json", "r", encoding="utf-8") as f:
    productos = json.load(f)

# Agregar el campo 'keywords' a cada producto
for producto in productos:
    producto["keywords"] = generar_keywords(producto["nombre"])

# Guardar en nuevo archivo
with open("06_productos_firebase.json", "w", encoding="utf-8") as f:
    json.dump(productos, f, ensure_ascii=False, indent=2)

print("Archivo actualizado con 'keywords' filtradas generado como 06_productos_firebase.json")