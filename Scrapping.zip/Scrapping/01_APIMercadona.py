import requests
import unidecode
import json
import re

# Función que detecta si el producto es marca blanca
def detectar_marca_blanca(nombre_bruto):
    nombre_limpio = nombre_bruto.lower()
    if any(marca in nombre_limpio for marca in ["hacendado", "deliplus", "bosque verde"]):
        return "Marca blanca"
    return "Desconocida"

# Función que construye un diccionario con información estructurada del producto
def construir_nombre(producto):
    nombre_bruto = producto.get("display_name", "")
    envase = (producto.get("packaging") or "").lower()
    info_precio = producto.get("price_instructions", {})

    # Detectar marca blanca
    marca_normalizada = detectar_marca_blanca(nombre_bruto)

    # Precio
    try:
        precio_unitario = float(info_precio.get("unit_price") or 0)
        if precio_unitario > 100:  # sospechoso, usar bulk_price
            precio_unitario = float(info_precio.get("bulk_price", 0))
    except:
        precio_unitario = float(info_precio.get("bulk_price", 0))

    # Cantidad
    cantidad = info_precio.get("unit_size")
    unidad = (info_precio.get("size_format") or "").lower()
    selling_method = info_precio.get("selling_method")

    # Normalizar nombre
    nombre_limpio = unidecode.unidecode(nombre_bruto)
    nombre_limpio = re.sub(r'\b(hacendado|deliplus|bosque verde)\b', '', nombre_limpio, flags=re.IGNORECASE)
    nombre_limpio = nombre_limpio.strip()

    # Lógica de cantidad
    cantidad_str = ""
    if cantidad:
        try:
            cantidad = float(cantidad)
            if cantidad == 0:
                cantidad_str = ""
            elif cantidad < 1 and unidad == "kg":
                gramos = int(cantidad * 1000)
                cantidad_str = f"{gramos} g"
            else:
                unidad_formateada = "Kg" if unidad == "kg" else unidad
                cantidad_str = f"{cantidad} {unidad_formateada}"
        except:
            cantidad_str = ""
    elif selling_method == 1 and info_precio.get("bulk_price"):
        cantidad_str = "1 Kg"


    # Armar nombre final
    partes_nombre = [
        nombre_limpio,
        envase,
        cantidad_str
    ]
    nombre_final = " ".join([parte for parte in partes_nombre if parte]).strip()

    return {
    "id": producto.get("id"),
    "nombre": nombre_final[0].upper() + nombre_final[1:],
    "marca": marca_normalizada,
    "precio": precio_unitario
    }

# Lista para almacenar productos sin duplicados y conjunto para controlar vistos
productos_guardados = []
productos_vistos = set()

# Iteración por IDs de categoría (de la 27 a la 244 incluidas)
for id_categoria in range(27, 245):
    url = f"https://tienda.mercadona.es/api/categories/{id_categoria}/"
    print(f"Revisando categoría ID {id_categoria}")
    try:
        respuesta = requests.get(url)
        datos = respuesta.json()

        # Iteración por subcategorías dentro de la categoría
        for subcategoria in datos.get("categories", []):
            for producto in subcategoria.get("products", []):
                id_producto = producto.get("id")
                if id_producto in productos_vistos:
                    continue  # Omitir productos ya procesados

                productos_vistos.add(id_producto)

                try:
                    # Construcción del diccionario del producto y almacenamiento
                    info = construir_nombre(producto)
                    productos_guardados.append({
                        "id": info["id"],
                        "nombre": info["nombre"],
                        "marca": info["marca"],
                        "supermercado": {
                            "mercadona": {
                                "precio": info["precio"]
                            }
                        }
                    })
                except Exception as e:
                    print(f"Error procesando producto {id_producto}: {e}")
    except Exception as e:
        print(f"Error al cargar categoría {id_categoria}: {e}")

# Escritura del resultado en archivo JSON
with open("01_productos_mercadona.json", "w", encoding="utf-8") as archivo:
    json.dump(productos_guardados, archivo, ensure_ascii=False, indent=2)

print(f"\nProductos guardados sin duplicados en 01_productos_mercadona.json")
