import json

# -----------------------------
# Cargar archivos
# -----------------------------

with open('01_productos_mercadona.json', 'r', encoding='utf-8') as f:
    mercadona = json.load(f)

with open('03_productos_comparados_final.json', 'r', encoding='utf-8') as f:
    comparados = json.load(f)

# -----------------------------
# Crear diccionario de matches
# -----------------------------

mapa_comparados = {p['id_mercadona']: p for p in comparados}

# -----------------------------
# Construir JSON final
# -----------------------------

salida = []

for prod in mercadona:
    id_ = prod['id']
    nombre = prod['nombre']
    marca = prod['marca']
    precio_m = float(prod['supermercado']['mercadona']['precio'])

    # Si el producto tiene match
    if id_ in mapa_comparados:
        match = mapa_comparados[id_]
        precio_d = match.get("precio_dia")
        unit_m = match.get("precio_unitario_mercadona")
        unit_d = match.get("precio_unitario_dia")

        if precio_d is not None and unit_m is not None and unit_d is not None:
            diferencia_total = abs(precio_m - precio_d)
            diferencia_unitaria = abs(unit_m - unit_d)

            if diferencia_total < diferencia_unitaria:
                precio_final_m = precio_m
                precio_final_d = precio_d
            else:
                precio_final_m = unit_m
                precio_final_d = unit_d

            # Si son iguales, se quedan los precios totales
            if diferencia_total == diferencia_unitaria:
                precio_final_m = precio_m
                precio_final_d = precio_d
        else:
            # Si no hay datos de unidades o precios, fallback
            precio_final_m = precio_m
            precio_final_d = precio_d if precio_d is not None else -1
    else:
        # Si no hay match en DIA
        precio_final_m = precio_m
        precio_final_d = -1

    salida.append({
        "id": id_,
        "nombre": nombre,
        "marca": marca,
        "supermercado": {
            "mercadona": {
                "precio": round(precio_final_m, 2) if precio_final_m is not None else -1
            },
            "dia": {
                "precio": round(precio_final_d, 2) if precio_final_d is not None else -1
            }
        }
    })

# -----------------------------
# Guardar resultado
# -----------------------------

with open('04_precios_mercadona.json', 'w', encoding='utf-8') as f:
    json.dump(salida, f, indent=2, ensure_ascii=False)

print(f"✅ JSON final guardado como '04_precios_mercadona.json' con {len(salida)} productos.")
