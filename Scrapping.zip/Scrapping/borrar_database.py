import firebase_admin
from firebase_admin import credentials, firestore

# Inicializar Firebase con tu clave de servicio
cred = credentials.Certificate("./credenciales_firebase.json")  # ← CAMBIA ESTA RUTA PARA LAS CREDENCIALES DE FIREBASE
firebase_admin.initialize_app(cred)

db = firestore.client()

# Nombre de la colección a borrar
coleccion = 'usuarios'

# Confirmación de seguridad
confirmar = input(f"⚠️ Esto eliminará TODOS los documentos de la colección '{coleccion}'. ¿Continuar? (y/N): ").lower()
if confirmar != 'y':
    print("❌ Cancelado por el usuario.")
    exit()

# Eliminar documentos
docs = db.collection(coleccion).stream()
contador = 0
for doc in docs:
    doc.reference.delete()
    contador += 1

print(f"✅ Eliminados {contador} documentos de la colección '{coleccion}'.")
