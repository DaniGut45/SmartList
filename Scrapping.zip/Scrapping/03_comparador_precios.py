import json
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def normalizar_precio(precio_raw):
    if isinstance(precio_raw, (int, float)):
        return float(precio_raw)
    return float(precio_raw.replace('\xa0', '').replace('€', '').replace(',', '.').strip())

def extraer_cantidad_y_unidad(nombre):
    nombre = nombre.lower()

    # Detectar multipacks tipo "6 x 25 cl", "4x330 ml", etc.
    multi = re.search(r'(\d+)\s*[x×]\s*(\d+(?:[.,]\d+)?)\s*(kg|g|l|ml|cl)', nombre)
    if multi:
        unidades = int(multi.group(1))
        cantidad = float(multi.group(2).replace(',', '.'))
        unidad = multi.group(3)
    else:
        match = re.search(r'(\d+(?:[.,]\d+)?)\s*(kg|g|l|ml|cl)', nombre)
        if not match:
            return None, None
        unidades = 1
        cantidad = float(match.group(1).replace(',', '.'))
        unidad = match.group(2)

    # Convertir todo a kg o litros
    if unidad in ['g', 'ml', 'cl']:
        if unidad == 'g':
            cantidad /= 1000
        elif unidad == 'ml':
            cantidad /= 1000
        elif unidad == 'cl':
            cantidad /= 100  # 100 cl = 1 l
        unidad = 'kg' if unidad == 'g' else 'l'

    total = round(cantidad * unidades, 3)
    return total, unidad

def calcular_precio_unitario(precio, cantidad):
    if cantidad:
        return round(precio / cantidad, 2)
    return None

def separar_por_marca(productos):
    blancas = [p for p in productos if p['marca'].lower() == 'marca blanca']
    comerciales = [p for p in productos if p['marca'].lower() != 'marca blanca']
    return blancas, comerciales

def comparar_grupos(productos_m, productos_d, umbral=0.50):
    if not productos_m or not productos_d:
        return []

    nombres_m = [p['nombre'].lower() for p in productos_m]
    nombres_d = [p['nombre'].lower() for p in productos_d]
    all_nombres = nombres_m + nombres_d

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(all_nombres)

    sim_matrix = cosine_similarity(tfidf_matrix[:len(nombres_m)], tfidf_matrix[len(nombres_m):])

    matches = []
    usados_mercadona = set()
    usados_dia = set()

    for idx_m, fila_sim in enumerate(sim_matrix):
        best_idx = fila_sim.argmax()
        best_score = fila_sim[best_idx]

        if best_score < umbral:
            continue
        if idx_m in usados_mercadona or best_idx in usados_dia:
            continue

        prod_m = productos_m[idx_m]
        prod_d = productos_d[best_idx]

        try:
            precio_m = float(prod_m["supermercado"]["mercadona"]["precio"])
            precio_d = normalizar_precio(prod_d["precio"])
        except:
            continue

        cant_m, unidad_m = extraer_cantidad_y_unidad(prod_m["nombre"])
        cant_d, unidad_d = extraer_cantidad_y_unidad(prod_d["nombre"])

        if unidad_m and unidad_d and unidad_m != unidad_d:
            continue

        precio_unitario_m = calcular_precio_unitario(precio_m, cant_m)
        precio_unitario_d = calcular_precio_unitario(precio_d, cant_d)

        match = {
            "id_mercadona": prod_m["id"],
            "nombre_mercadona": prod_m["nombre"],
            "precio_mercadona": precio_m,
            "precio_unitario_mercadona": precio_unitario_m,
            "nombre_dia": prod_d["nombre"],
            "precio_dia": precio_d,
            "precio_unitario_dia": precio_unitario_d,
            "similitud": round(best_score, 3)
        }
        matches.append(match)
        usados_mercadona.add(idx_m)
        usados_dia.add(best_idx)

    return matches

# Main
with open('01_productos_mercadona.json', 'r', encoding='utf-8') as f:
    mercadona = json.load(f)

with open('02.2_productos_dia.json', 'r', encoding='utf-8') as f:
    dia = json.load(f)

mercadona_blancas, mercadona_comerciales = separar_por_marca(mercadona)
dia_blancas, dia_comerciales = separar_por_marca(dia)

matches_blancas = comparar_grupos(mercadona_blancas, dia_blancas)
matches_comerciales = comparar_grupos(mercadona_comerciales, dia_comerciales)

matches_totales = matches_blancas + matches_comerciales

with open('03_productos_comparados_final.json', 'w', encoding='utf-8') as f:
    json.dump(matches_totales, f, indent=2, ensure_ascii=False)

print("✅ Comparación TF-IDF completada con soporte de packs. Resultados en '03_productos_comparados_final.json'")
